make pthread n=100 t=2
./pthread 1000 2

make serial n=100 t=2
./serial 1000 2  

make openmp n=100 t=2
